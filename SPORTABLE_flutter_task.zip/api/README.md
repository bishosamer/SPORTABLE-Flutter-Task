## Project setup
```
npm install
```

### Start API
```
npm start